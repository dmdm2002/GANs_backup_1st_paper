
from tensorflow import image as tim
import tensorflow as tf
import os
import sys
import csv
import timeit
import numpy as np

import imlib as im
import numpy as np
import pylib as py
import tensorflow as tf
import tensorflow.keras as keras
import tf2lib as tl
import tf2gan as gan
import tqdm

import data
import module
import random
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

sys.path.append(os.path.dirname(os.path.dirname(__file__)))
csv.register_dialect(
    'mydialect',
    delimiter=',',
    quotechar='"',
    doublequote=True,
    skipinitialspace=True,
    lineterminator='\r\n',
    quoting=csv.QUOTE_MINIMAL)
# ==============================================================================
# =                                   param                                    =
# ==============================================================================



py.arg('--experiment_dir', default='generate_2fold(B)_2')
py.arg('--batch_size', type=int, default=24)
test_args = py.args()

args = py.args_from_yaml(py.join(test_args.experiment_dir, 'settings.yml'))
args.__dict__.update(test_args.__dict__)

# output_dir
output_dir = py.join('output_interclass_shuffle_2fold(B)', args.dataset)

# ==============================================================================
# =                                    test                                    =
# ==============================================================================
avgpixel=111
avgpixel_normalize=-0.12967


SHUFFLE_BUFFER_SIZE = 8
numberofclass = 301

created_path = 'generate_2fold(B)_2/'

originpath = 'dataset/vein2vein/trainB_inter_class(only aug)/'

A_img_paths = py.glob(py.join(args.datasets_dir, args.dataset, 'trainB_inter_class(only aug)'), '*/*', True)

A_dataset_test = data.make_dataset(A_img_paths, args.batch_size, args.load_size, args.crop_size,
                                   training=False, drop_remainder=False, shuffle=False, repeat=1)

def make_channel_avg(origin_image_value,created_image_value):
    created_image_value=created_image_value.numpy()
    origin_image_value=origin_image_value.numpy()

    orimean_arr=[]
    cremean_arr=[]
    oridiff_arr=[]
    crediff_arr=[]


    for i in range(args.batch_size):
        orimean=tf.reduce_mean(origin_image_value[i , :, :, :])
        orimean_arr.append(orimean)
        cremean=tf.reduce_mean(created_image_value[i, :, :, :])
        cremean_arr.append(cremean)
        oridiff=orimean-avgpixel_normalize
        oridiff_arr.append(oridiff)
        crediff=cremean-avgpixel_normalize
        crediff_arr.append(crediff)

        #region created image

        created_image_value[i, :, :, :] = created_image_value[i, :, :, :] - crediff.numpy()


        grater_mask=created_image_value[i, :, :, :]>1
        created_image_value[i,grater_mask]=1
        less_mask = created_image_value[i, :, :, :] <-1
        created_image_value[i,less_mask]=-1

        #endregion



        #region origin image

        origin_image_value[i, :, :, :] = origin_image_value[i, :, :, :] - oridiff.numpy()


        grater_mask = origin_image_value[i, :, :, :] > 1
        origin_image_value[i, grater_mask] = 1
        less_mask = origin_image_value[i, :, :, :] < -1
        origin_image_value[i, less_mask] = -1

        #endregion
    return  origin_image_value,created_image_value,orimean_arr,cremean_arr,oridiff_arr,crediff_arr



## 원본이미지 채널별 평균 계산 --> 개별이미지에 대한 평균 계산이후 평균보다 작거나 큰만큼 개별 픽셀 값 보정 --> 계산
for i in range(92, 93):
    path_per_epoch = created_path + str(i) + 'epoch'

    B_img_paths = py.glob(py.join(path_per_epoch, 'train_A2B'), '*.bmp')

    B_dataset_test = data.make_dataset(B_img_paths, args.batch_size, args.load_size, args.crop_size,
                                       training=False, drop_remainder=False, shuffle=False, repeat=1)

    zipeed_dataset = tf.data.Dataset.zip((A_dataset_test, B_dataset_test))

    scores = []
    chk = 0
    idx = 0
    epoch_start = timeit.default_timer()
    for n, (input_image, target) in zipeed_dataset.enumerate():
        chk += 1
        '''
        im1 = tf.io.read_file(input_image)
        im1 = im.decode_bmp(im1, 3)
        im1 = resize(im1)

        im2 = tf.io.read_file(target)
        im2 = im.decode_bmp(im2, 3)

        # Compute SSIM over tf.float32 Tensors.
        im1 = im.convert_image_dtype(input_image, tf.float32)
        im2 = im.convert_image_dtype(target, tf.float32)
         '''
        origin,target,orimean,cremean,oridiff,crediff=make_channel_avg(input_image,target)

        ssim2 = tim.ssim(tf.convert_to_tensor(origin),tf.convert_to_tensor(target), max_val=1.0, filter_size=11,
                         filter_sigma=1.5, k1=0.01, k2=0.03)
        iidx=0#이미지 저장용 idx
        for sc in ssim2:
            name = py.name(A_img_paths[idx])
            #im.imwrite(origin[iidx], 'generate_2fold(B)_2/92epoch_avg/origin_M/'+name+'origin'+'.bmp')
            #im.imwrite(target[iidx], 'generate_2fold(B)_2/92epoch_avg/A2B_M/'+name+'A2B'+'.bmp')
            f = open('generate_2fold(B)_2/all_92epoch_img_ssim_AVG_2_2.csv', 'a', newline='')
            wr = csv.writer(f)
            wr.writerow([name, sc.numpy(),orimean[iidx].numpy(),cremean[iidx].numpy(),oridiff[iidx].numpy(),crediff[iidx].numpy()])
            f.close()
            iidx+=1
            idx += 1
        '''
        ssim2 = tim.ssim(input_image, target, max_val=1.0, filter_size=11,
                        filter_sigma=1.5, k1=0.01, k2=0.03)

        scores.append(ssim2.numpy())
        if chk > 505:
            print(chk)
        if chk == 507:
            # socres  [234,52] 이기 떄문에 2번 계산해줌
            mean = sum(scores, 0.0) / len(scores)
            mean = sum(mean, 0.0) / len(mean)
            meanscores.append(['EPOCH' + str(i), mean])
            f = open('generate_2fold(B)/ssim.csv', 'a', newline='')
            wr = csv.writer(f)
            wr.writerow(meanscores[i-300])
            f.close()
            epoch_end = timeit.default_timer()
            print(str(i)+' EPOCH/SEC: ', epoch_end - epoch_start)
        '''



##52 234
##24 507
##12 1014
##8  1521


# 936 52  18